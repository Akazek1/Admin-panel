import { DropdownMenuSeparator } from "@/components/ui/dropdown-menu"
import { DropdownMenuItem } from "@/components/ui/dropdown-menu"
import { Search, Users, ArrowRight } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent } from "@/components/ui/dropdown-menu"
import Link from "next/link"
import { ModeToggle } from "@/components/mode-toggle"
import Image from "next/image"
import { MapPin, Copy } from "lucide-react"

export default function DashboardPage() {
  return (
    <div className="flex flex-col w-full min-h-screen">
      <header className="sticky top-0 z-30 flex h-14 items-center gap-4 border-b bg-background px-4 sm:static sm:h-auto sm:border-0 sm:bg-transparent sm:px-6">
        <h1 className="text-2xl font-semibold hidden md:block">Dashboard</h1>
        <div className="flex-1 text-center md:text-left">
          <p className="text-lg font-medium">Welcome back, John Doe!</p>
        </div>
        <div className="relative ml-auto flex-1 md:grow-0">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search..."
            className="w-full rounded-lg bg-background pl-8 md:w-[200px] lg:w-[336px]"
          />
        </div>
        <ModeToggle /> {/* Theme toggle button */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="secondary" size="icon" className="rounded-full">
              <Users className="h-5 w-5" />
              <span className="sr-only">Toggle user menu</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem>Settings</DropdownMenuItem>
            <DropdownMenuItem>Support</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Logout</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </header>
      <div className="flex-1 p-4 md:p-6 max-w-7xl mx-auto w-full">
        {/* Hero Section */}
        <section className="mb-16 pt-8 md:pt-12 lg:pt-16">
          <h1 className="text-4xl md:text-5xl font-bold text-darkText mb-4 leading-tight">
            Hello! I&apos;m <span className="text-accentGold">Toby</span>
          </h1>
          <h2 className="text-2xl md:text-3xl font-semibold text-darkText mb-4 flex items-center flex-wrap gap-2">
            Frontend Developer{" "}
            <span className="inline-flex items-center gap-1 rounded-full bg-darkCard px-3 py-1 text-sm text-muted-foreground">
              <MapPin className="h-4 w-4" /> Canada
            </span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mb-8 leading-relaxed">
            Frontend developer and design system specialist with over 9 years of experience focusing on user experience
            and design systems to create user-centered designs in SaaS products.
          </p>
          <div className="flex gap-4 flex-wrap">
            <Button className="bg-accentGold hover:bg-accentGoldHover text-darkBackground font-semibold px-6 py-3 rounded-lg transition-colors duration-200">
              About
            </Button>
            <Button
              variant="outline"
              className="border border-gray-700 text-darkText hover:bg-darkCard px-6 py-3 rounded-lg bg-transparent transition-colors duration-200"
            >
              <Copy className="h-4 w-4 mr-2" /> Copy mail
            </Button>
          </div>
        </section>

        {/* Selected Work Section */}
        <section className="mb-16">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-3xl font-bold text-darkText">Selected Work</h3>
            <Link
              href="#"
              className="text-accentGold hover:underline flex items-center gap-1 transition-colors duration-200"
            >
              View All <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="bg-darkCard border-none rounded-lg overflow-hidden shadow-lg transition-transform duration-200 hover:scale-[1.02]">
              <Image
                src="/images/ecommerce-platform.png"
                width={600}
                height={400}
                alt="Modern E-commerce Platform"
                className="w-full h-auto object-cover"
              />
              <CardContent className="p-6">
                <h4 className="text-xl font-semibold text-darkText mb-2">Modern E-commerce Platform</h4>
                <p className="text-sm text-muted-foreground">2024 - 2025</p>
              </CardContent>
            </Card>
            <Card className="bg-darkCard border-none rounded-lg overflow-hidden shadow-lg transition-transform duration-200 hover:scale-[1.02]">
              <Image
                src="/images/analytics-dashboard.png"
                width={600}
                height={400}
                alt="AI-Powered Analytics Dashboard"
                className="w-full h-auto object-cover"
              />
              <CardContent className="p-6">
                <h4 className="text-xl font-semibold text-darkText mb-2">AI-Powered Analytics Dashboard</h4>
                <p className="text-sm text-muted-foreground">2023 - 2024</p>
              </CardContent>
            </Card>
          </div>
        </section>

        <div className="grid gap-4 md:grid-cols-2 md:gap-8 lg:grid-cols-4">
          <Card className="transition-all duration-200 hover:scale-[1.02] hover:shadow-lg">
            <CardContent>
              <div className="text-2xl font-bold">$45,231.89</div>
              <p className="text-xs text-muted-foreground">{"20.1% from last month"}</p>
            </CardContent>
          </Card>
          <Card className="transition-all duration-200 hover:scale-[1.02] hover:shadow-lg">
            <CardContent>
              <div className="text-2xl font-bold">{"+2350"}</div>
              <p className="text-xs text-muted-foreground">{"180.1% from last month"}</p>
            </CardContent>
          </Card>
          <Card className="transition-all duration-200 hover:scale-[1.02] hover:shadow-lg">
            <CardContent>
              <div className="text-2xl font-bold">{"+12,234"}</div>
              <p className="text-xs text-muted-foreground">{"19% from last month"}</p>
            </CardContent>
          </Card>
          <Card className="transition-all duration-200 hover:scale-[1.02] hover:shadow-lg">
            <CardContent>
              <div className="text-2xl font-bold">{"+573"}</div>
              <p className="text-xs text-muted-foreground">{"201 since last hour"}</p>
            </CardContent>
          </Card>
        </div>
        <div className="grid gap-4 md:gap-8 lg:grid-cols-2 xl:grid-cols-3 mt-4">
          <Card className="xl:col-span-2">
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Customer</TableHead>
                    <TableHead className="hidden xl:table-column">Type</TableHead>
                    <TableHead className="hidden xl:table-column">Status</TableHead>
                    <TableHead className="hidden xl:table-column">Date</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>
                      <div className="font-medium">Liam Johnson</div>
                      <div className="hidden text-sm text-muted-foreground md:inline">liam@example.com</div>
                    </TableCell>
                    <TableCell className="hidden xl:table-column">Sale</TableCell>
                    <TableCell className="hidden xl:table-column">
                      <Badge className="text-xs" variant="outline">
                        Approved
                      </Badge>
                    </TableCell>
                    <TableCell className="hidden md:table-cell lg:hidden xl:table-column">2023-06-23</TableCell>
                    <TableCell className="text-right">$250.00</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>
                      <div className="font-medium">Olivia Smith</div>
                      <div className="hidden text-sm text-muted-foreground md:inline">olivia@example.com</div>
                    </TableCell>
                    <TableCell className="hidden xl:table-column">Refund</TableCell>
                    <TableCell className="hidden xl:table-column">
                      <Badge className="text-xs" variant="outline">
                        Declined
                      </Badge>
                    </TableCell>
                    <TableCell className="hidden md:table-cell lg:hidden xl:table-column">2023-06-24</TableCell>
                    <TableCell className="text-right">$150.00</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>
                      <div className="font-medium">Noah Williams</div>
                      <div className="hidden text-sm text-muted-foreground md:inline">noah@example.com</div>
                    </TableCell>
                    <TableCell className="hidden xl:table-column">Subscription</TableCell>
                    <TableCell className="hidden xl:table-column">
                      <Badge className="text-xs" variant="outline">
                        Approved
                      </Badge>
                    </TableCell>
                    <TableCell className="hidden md:table-cell lg:hidden xl:table-column">2023-06-25</TableCell>
                    <TableCell className="text-right">$350.00</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>
                      <div className="font-medium">Emma Brown</div>
                      <div className="hidden text-sm text-muted-foreground md:inline">emma@example.com</div>
                    </TableCell>
                    <TableCell className="hidden xl:table-column">Sale</TableCell>
                    <TableCell className="hidden xl:table-column">
                      <Badge className="text-xs" variant="outline">
                        Approved
                      </Badge>
                    </TableCell>
                    <TableCell className="hidden md:table-cell lg:hidden xl:table-column">2023-06-26</TableCell>
                    <TableCell className="text-right">$450.00</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>
                      <div className="font-medium">Liam Johnson</div>
                      <div className="hidden text-sm text-muted-foreground md:inline">liam@example.com</div>
                    </TableCell>
                    <TableCell className="hidden xl:table-column">Sale</TableCell>
                    <TableCell className="hidden xl:table-column">
                      <Badge className="text-xs" variant="outline">
                        Approved
                      </Badge>
                    </TableCell>
                    <TableCell className="hidden md:table-cell lg:hidden xl:table-column">2023-06-27</TableCell>
                    <TableCell className="text-right">$550.00</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="grid gap-8">
              <div className="flex items-center gap-4">
                <div className="grid gap-1">
                  <p className="text-sm font-medium leading-none">Olivia Smith</p>
                  <p className="text-sm text-muted-foreground">olivia.smith@example.com</p>
                </div>
                <div className="ml-auto font-medium">+$1,999.00</div>
              </div>
              <div className="flex items-center gap-4">
                <div className="grid gap-1">
                  <p className="text-sm font-medium leading-none">Jackson Lee</p>
                  <p className="text-sm text-muted-foreground">jackson.lee@example.com</p>
                </div>
                <div className="ml-auto font-medium">+$39.00</div>
              </div>
              <div className="flex items-center gap-4">
                <div className="grid gap-1">
                  <p className="text-sm font-medium leading-none">Isabella Nguyen</p>
                  <p className="text-sm text-muted-foreground">isabella.nguyen@example.com</p>
                </div>
                <div className="ml-auto font-medium">+$299.00</div>
              </div>
              <div className="flex items-center gap-4">
                <div className="grid gap-1">
                  <p className="text-sm font-medium leading-none">William Kim</p>
                  <p className="text-sm text-muted-foreground">will@example.com</p>
                </div>
                <div className="ml-auto font-medium">+$99.00</div>
              </div>
              <div className="flex items-center gap-4">
                <div className="grid gap-1">
                  <p className="text-sm font-medium leading-none">Sofia Davis</p>
                  <p className="text-sm text-muted-foreground">sofia.davis@example.com</p>
                </div>
                <div className="ml-auto font-medium">+$39.00</div>
              </div>
            </CardContent>
          </Card>
          <Card className="lg:col-span-2 xl:col-span-1">
            <CardContent>
              <div className="h-[200px] w-full rounded-lg bg-muted/50 flex items-center justify-center text-muted-foreground">
                {/* Placeholder for a chart */}
                Chart Placeholder
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
