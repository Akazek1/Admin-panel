import type React from "react"
import { ThemeProvider } from "@/components/theme-provider"
import "../app/globals.css" // Ensure global styles are imported
import { PortfolioSidebar } from "@/components/portfolio-sidebar"

export default async function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
          <div className="flex min-h-screen bg-darkBackground text-darkText">
            <PortfolioSidebar />
            <main className="flex-1 overflow-auto">{children}</main>
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}

export const metadata = {
      generator: 'v0.dev'
    };
