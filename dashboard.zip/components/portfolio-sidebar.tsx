"use client"

import { Home, Folder, Store, User, Rss, Mail, Twitter, Facebook, Dribbble } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { cn } from "@/lib/utils"
import { usePathname } from "next/navigation"

const mainNavigation = [
  {
    title: "Homepage",
    url: "/",
    icon: Home,
  },
  {
    title: "Projects",
    url: "/projects",
    icon: Folder,
  },
  {
    title: "Store",
    url: "/store",
    icon: Store,
  },
  {
    title: "About",
    url: "/about",
    icon: User,
  },
  {
    title: "Blog",
    url: "/blog",
    icon: Rss,
  },
  {
    title: "Contact",
    url: "/contact",
    icon: Mail,
  },
]

const socialNavigation = [
  {
    title: "Twitter",
    url: "#",
    icon: Twitter,
  },
  {
    title: "Facebook",
    url: "#",
    icon: Facebook,
  },
  {
    title: "Dribbble",
    url: "#",
    icon: Dribbble,
  },
]

export function PortfolioSidebar() {
  const pathname = usePathname()

  return (
    <aside className="w-64 flex-shrink-0 border-r border-gray-800 bg-darkBackground p-4 flex flex-col">
      <div className="flex items-center gap-3 mb-8">
        <Image src="/images/toby-avatar.png" width={48} height={48} alt="Toby Belhome" className="rounded-full" />
        <div>
          <h2 className="text-lg font-semibold text-darkText">Toby Belhome</h2>
          <p className="text-sm text-muted-foreground">Frontend Developer</p>
        </div>
      </div>

      <nav className="flex-1 space-y-2">
        {mainNavigation.map((item) => (
          <Link
            key={item.title}
            href={item.url}
            className={cn(
              "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-sidebarActive",
              pathname === item.url ? "bg-sidebarActive text-darkText" : "text-muted-foreground",
            )}
          >
            <item.icon className="h-5 w-5" />
            {item.title}
          </Link>
        ))}

        <div className="pt-6 text-xs font-semibold uppercase text-muted-foreground">Social</div>
        {socialNavigation.map((item) => (
          <Link
            key={item.title}
            href={item.url}
            className="flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors text-muted-foreground hover:bg-sidebarActive"
          >
            <item.icon className="h-5 w-5" />
            {item.title}
          </Link>
        ))}
      </nav>
    </aside>
  )
}
